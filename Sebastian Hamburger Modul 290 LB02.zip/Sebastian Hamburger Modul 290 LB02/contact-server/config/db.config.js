module.exports = {
    HOST: "localhost",
    USER: "adminContactDB",
    PASSWORD: "hello",
    DB: "contactdb"
}
